export {default} from "./f8d95dcdd62b9612@28.js";

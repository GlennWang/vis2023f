export {default} from "./502142678d485be2@79.js";

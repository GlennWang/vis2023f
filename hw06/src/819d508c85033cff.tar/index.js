export {default} from "./819d508c85033cff@65.js";
